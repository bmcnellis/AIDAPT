#!/usr/bin/env python3
# prepare merged Pleiades footprints

import argparse
import re
import tempfile
import zipfile
from pathlib import Path

import geopandas as gpd
import pandas as pd
from shapely import make_valid

DEFAULT_INPUT = Path("per_date_shapefiles.zip")
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "inputs" / "pleiades_footprints_merged.gpkg"
DEFAULT_CRS = "EPSG:3577"
DATE_RE = re.compile(r"(^|/)(\d{4}-\d{2}-\d{2})(/|$)")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=DEFAULT_INPUT, help="ZIP containing dated footprint shapefiles")
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Output GeoPackage")
    p.add_argument("--crs", default=DEFAULT_CRS, help="Output projected CRS")
    return p.parse_args()


def main():
    args = parse_args()
    if not args.input.exists():
        raise FileNotFoundError(f"Footprint ZIP not found: {args.input.resolve()}")

    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "src"
        src.mkdir()
        with zipfile.ZipFile(args.input) as z:
            z.extractall(src)

        frames = []
        matched_files = 0

        for shp in sorted(src.rglob("*.shp")):
            rel = "/" + shp.relative_to(src).as_posix()
            match = DATE_RE.search(rel)

            gdf = gpd.read_file(shp)
            if gdf.empty:
                continue
            if gdf.crs is None:
                raise RuntimeError(f"Missing CRS: {shp}")

            # some source files already include the date
            existing_date_col = next((c for c in gdf.columns if c.lower() == "date"), None)
            if existing_date_col is None and match is None:
                continue
            matched_files += 1

            gdf = gdf.to_crs(args.crs)
            gdf = gdf[gdf.geometry.notna()].copy()
            gdf["geometry"] = gdf.geometry.map(make_valid)
            if existing_date_col is not None:
                gdf["date"] = pd.to_datetime(gdf[existing_date_col], errors="raise").dt.strftime("%Y-%m-%d")
            else:
                gdf["date"] = match.group(2)
            frames.append(gdf[["date", "geometry"]])

        if not frames:
            raise RuntimeError("No dated footprint shapefiles found")

        merged = gpd.GeoDataFrame(
            pd.concat(frames, ignore_index=True),
            geometry="geometry",
            crs=args.crs,
        )
        merged = merged[~merged.geometry.is_empty].copy()
        merged["date"] = pd.to_datetime(merged["date"], errors="raise").dt.strftime("%Y-%m-%d")
        merged = merged.sort_values("date").reset_index(drop=True)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        args.output.unlink()
    merged.to_file(args.output, layer="footprints", driver="GPKG")

    print(f"Matched shapefiles: {matched_files:,}")
    print(f"Features: {len(merged):,}")
    print(f"Unique dates: {merged['date'].nunique():,}")
    print(f"Date range: {merged['date'].min()} to {merged['date'].max()}")
    print(f"Output CRS: {args.crs}")
    print(f"Wrote: {args.output.resolve()}")


if __name__ == "__main__":
    main()
