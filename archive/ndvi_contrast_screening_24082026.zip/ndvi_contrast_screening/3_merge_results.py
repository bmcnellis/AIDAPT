#!/usr/bin/env python3
# merge per-date results and select usable dates

import json
import numpy as np
import pandas as pd

import config as cfg


def contrast_fraction_field(threshold):
    suffix = f"{float(threshold):.2f}".replace("-", "m").replace(".", "p")
    return f"contrast_fraction_ge_{suffix}"


def contrast_landscape_coverage_field(threshold):
    suffix = f"{float(threshold):.2f}".replace("-", "m").replace(".", "p")
    return f"contrast_landscape_coverage_ge_{suffix}"


def spatial_landscape_coverage_p25_field(threshold):
    return f"spatial_cell_{contrast_landscape_coverage_field(threshold)}_p25"


def coverage_threshold_suffix(threshold):
    return f"{int(round(float(threshold) * 100)):02d}pct"



def _numeric_columns(df):
    fixed = {
        "landsat_observation_count",
        "landsat_window_days_used",
        "closest_landsat_days",
        "furthest_landsat_days",
        "aoi_area_km2",
        "pleiades_footprint_area_km2",
        "pleiades_footprint_fraction_of_aoi",
        "eligible_agricultural_pixels",
        "valid_landsat_pixels",
        "valid_coverage_fraction",
        "usable_contrast_threshold",
        "usable_contrast_pixels",
        "usable_contrast_fraction_valid",
        "usable_contrast_landscape_coverage",
        "reference_contrast_threshold",
        "reference_high_contrast_pixels",
        "reference_high_contrast_fraction_valid",
        "spatial_cells_total",
        "spatial_cells_evaluable",
        "spatial_evaluable_fraction",
        "spatial_cell_p975_p10",
        "spatial_cell_p975_p25",
        "spatial_cell_p975_p50",
        "spatial_cell_p975_p75",
        "spatial_cell_p975_p90",
        "spatial_cell_p975_iqr",
    }
    dynamic_prefixes = (
        "contrast_p",
        "contrast_fraction_ge_",
        "contrast_landscape_coverage_ge_",
        "spatial_cell_contrast_fraction_ge_",
        "spatial_cell_contrast_landscape_coverage_ge_",
    )
    return [
        c for c in df.columns
        if c in fixed or c.startswith(dynamic_prefixes)
    ]


def _add_empirical_ranking(df, mask, column):
    rank_col = f"{column}_rank_best1"
    pct_col = f"{column}_empirical_percentile"
    df[rank_col] = np.nan
    df[pct_col] = np.nan
    values = pd.to_numeric(df.loc[mask, column], errors="coerce").dropna()
    if values.empty:
        return
    df.loc[values.index, rank_col] = values.rank(method="min", ascending=False)
    df.loc[values.index, pct_col] = values.rank(method="average", pct=True) * 100.0


def _sorted_subset(df, mask, column):
    subset = df.loc[mask & pd.to_numeric(df[column], errors="coerce").notna()].copy()
    if subset.empty:
        return subset
    subset[column] = pd.to_numeric(subset[column], errors="coerce")
    for tie in ("valid_coverage_fraction", "contrast_p975"):
        if tie in subset.columns:
            subset[tie] = pd.to_numeric(subset[tie], errors="coerce")
    sort_cols = [column]
    ascending = [False]
    for tie in ("valid_coverage_fraction", "contrast_p975"):
        if tie in subset.columns and tie != column:
            sort_cols.append(tie)
            ascending.append(False)
    sort_cols.append("date")
    ascending.append(True)
    return subset.sort_values(sort_cols, ascending=ascending, na_position="last")


def _top_fraction_mask(
    df, mask, column, fraction
):
    out = pd.Series(False, index=df.index)
    subset = _sorted_subset(df, mask, column)
    if subset.empty:
        return out
    n_select = max(1, int(np.ceil(len(subset) * float(fraction))))
    out.loc[subset.index[:n_select]] = True
    return out


def _top_n_per_year_mask(
    df, mask, column, n
):
    out = pd.Series(False, index=df.index)
    years = pd.to_numeric(df.get("year"), errors="coerce")
    for year in sorted(years[mask & years.notna()].dropna().astype(int).unique()):
        subset = _sorted_subset(df, mask & years.eq(year), column)
        if subset.empty:
            continue
        out.loc[subset.index[: min(int(n), len(subset))]] = True
    return out


def _add_within_year_rank(
    df, mask, column, output_column
):
    df[output_column] = np.nan
    years = pd.to_numeric(df.get("year"), errors="coerce")
    for year in sorted(years[mask & years.notna()].dropna().astype(int).unique()):
        subset = _sorted_subset(df, mask & years.eq(year), column)
        if subset.empty:
            continue
        df.loc[subset.index, output_column] = np.arange(1, len(subset) + 1)


def _validate_usable_threshold(df):
    threshold = float(cfg.USABLE_CONTRAST_THRESHOLD)
    metric = contrast_landscape_coverage_field(threshold)
    if metric not in df.columns:
        raise ValueError(f"No saved metric for contrast threshold {threshold:.2f}")
    return metric


def main():
    files = sorted(cfg.EXPORT_DIR.glob("date_contrast_*.json"))
    if not files:
        raise RuntimeError(f"No completed date results in {cfg.EXPORT_DIR}")

    rows = [json.loads(path.read_text(encoding="utf-8")) for path in files]
    df = pd.DataFrame(rows)
    df["date"] = df["date"].astype(str)
    parsed_dates = pd.to_datetime(df["date"], errors="coerce")
    if parsed_dates.isna().any():
        bad = df.loc[parsed_dates.isna(), "date"].tolist()[:5]
        raise ValueError(f"Could not parse one or more acquisition dates: {bad}")
    df["year"] = parsed_dates.dt.year.astype(int)

    for col in _numeric_columns(df):
        df[col] = pd.to_numeric(df[col], errors="coerce")

    usable_metric = _validate_usable_threshold(df)
    usable_valid_metric = contrast_fraction_field(cfg.USABLE_CONTRAST_THRESHOLD)

    coverage_thresholds = tuple(
        float(value) for value in cfg.COVERAGE_SENSITIVITY_THRESHOLDS
    )
    ok = df["status"].eq("OK")
    coverage = df["valid_coverage_fraction"].fillna(0)
    sample_ok = (
        df["valid_landsat_pixels"].fillna(0)
        >= cfg.MIN_DATE_VALID_PIXELS_FOR_RANKING
    )
    valid_ok = coverage >= cfg.MIN_DATE_VALID_COVERAGE
    calibration_ok = ok & valid_ok & sample_ok

    df["passes_valid_coverage"] = valid_ok
    df["passes_minimum_sample"] = sample_ok
    df["eligible_for_calibration"] = calibration_ok
    df["primary_usable_contrast_threshold"] = float(cfg.USABLE_CONTRAST_THRESHOLD)
    df["primary_ranking_metric"] = usable_metric

    ranking_metrics = [
        usable_metric,
        usable_valid_metric,
        "contrast_p90",
        "contrast_p95",
        "contrast_p975",
        "contrast_p99",
    ]
    ranking_metrics += [
        contrast_fraction_field(t) for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
    ]
    ranking_metrics += [
        contrast_landscape_coverage_field(t)
        for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
    ]
    ranking_metrics += [
        spatial_landscape_coverage_p25_field(cfg.USABLE_CONTRAST_THRESHOLD),
        f"spatial_cell_{usable_metric}_p50",
        "spatial_cell_p975_p25",
        "spatial_cell_p975_p50",
    ]
    for metric in dict.fromkeys(ranking_metrics):
        if metric in df.columns:
            _add_empirical_ranking(df, calibration_ok, metric)

    sensitivity_masks = {}
    for threshold in coverage_thresholds:
        suffix = coverage_threshold_suffix(threshold)
        pass_mask = coverage >= threshold
        eligible_mask = ok & pass_mask & sample_ok
        sensitivity_masks[threshold] = eligible_mask
        df[f"passes_valid_coverage_{suffix}"] = pass_mask
        df[f"eligible_for_calibration_{suffix}"] = eligible_mask

        values = pd.to_numeric(df.loc[eligible_mask, usable_metric], errors="coerce").dropna()
        rank_col = f"{usable_metric}_rank_best1_{suffix}"
        pct_col = f"{usable_metric}_empirical_percentile_{suffix}"
        df[rank_col] = np.nan
        df[pct_col] = np.nan
        if not values.empty:
            df.loc[values.index, rank_col] = values.rank(method="min", ascending=False)
            df.loc[values.index, pct_col] = values.rank(method="average", pct=True) * 100.0

        for fraction in (0.10, 0.15, 0.20):
            label = int(round(fraction * 100))
            df[f"diagnostic_top_{label}pct_usable_coverage_{suffix}"] = _top_fraction_mask(
                df, eligible_mask, usable_metric, fraction
            )

    for fraction in (0.10, 0.15, 0.20):
        label = int(round(fraction * 100))
        df[f"diagnostic_top_{label}pct_usable_coverage"] = _top_fraction_mask(
            df, calibration_ok, usable_metric, fraction
        )
        df[f"diagnostic_top_{label}pct_p975"] = _top_fraction_mask(
            df, calibration_ok, "contrast_p975", fraction
        )

    mode = cfg.DATE_SELECTION_MODE.lower()
    if mode.startswith("p975"):
        selection_metric = "contrast_p975"
    else:
        selection_metric = usable_metric

    global_selection_columns = {}
    for fraction in tuple(float(v) for v in cfg.GLOBAL_TOP_DATE_FRACTIONS):
        label = int(round(fraction * 100))
        column = f"selected_global_top{label}"
        df[column] = _top_fraction_mask(df, calibration_ok, selection_metric, fraction)
        global_selection_columns[fraction] = column

    within_year_rank_col = f"{selection_metric}_rank_within_year_best1"
    _add_within_year_rank(df, calibration_ok, selection_metric, within_year_rank_col)
    annual_selection_columns = {}
    for n in tuple(int(v) for v in cfg.ANNUAL_TOP_DATE_COUNTS):
        column = f"selected_annual_top{n}"
        df[column] = _top_n_per_year_mask(df, calibration_ok, selection_metric, n)
        annual_selection_columns[n] = column

    if mode == "deferred":
        auto = pd.Series(False, index=df.index)
        rule = (
            "AUTOMATIC SELECTION DEFERRED: review broad usable-contrast coverage "
            "before choosing a final date set"
        )
    elif mode == "usable_coverage_top_fraction":
        auto = _top_fraction_mask(
            df, calibration_ok, usable_metric, cfg.SELECT_TOP_DATE_FRACTION
        )
        rule = (
            f"valid Landsat coverage >= {cfg.MIN_DATE_VALID_COVERAGE:.0%}; "
            f"valid agricultural pixels >= {cfg.MIN_DATE_VALID_PIXELS_FOR_RANKING}; "
            f"top {cfg.SELECT_TOP_DATE_FRACTION:.0%} by agricultural-landscape coverage "
            f"with C{cfg.BACKGROUND_RADIUS_M:g} >= {cfg.USABLE_CONTRAST_THRESHOLD:.2f}"
        )
    elif mode == "usable_coverage_absolute":
        auto = calibration_ok & (
            pd.to_numeric(df[usable_metric], errors="coerce").fillna(float("-inf"))
            >= cfg.MIN_USABLE_CONTRAST_LANDSCAPE_COVERAGE
        )
        rule = (
            f"valid Landsat coverage >= {cfg.MIN_DATE_VALID_COVERAGE:.0%}; "
            f"valid agricultural pixels >= {cfg.MIN_DATE_VALID_PIXELS_FOR_RANKING}; "
            f"agricultural-landscape coverage with C{cfg.BACKGROUND_RADIUS_M:g} >= "
            f"{cfg.USABLE_CONTRAST_THRESHOLD:.2f} >= "
            f"{cfg.MIN_USABLE_CONTRAST_LANDSCAPE_COVERAGE:.0%}"
        )
    elif mode == "p975_top_fraction":
        auto = _top_fraction_mask(
            df, calibration_ok, "contrast_p975", cfg.SELECT_TOP_DATE_FRACTION
        )
        rule = (
            f"LEGACY COMPARISON: valid coverage >= {cfg.MIN_DATE_VALID_COVERAGE:.0%}; "
            f"top {cfg.SELECT_TOP_DATE_FRACTION:.0%} by C{cfg.BACKGROUND_RADIUS_M:g} p97.5"
        )
    elif mode == "p975_absolute":
        auto = calibration_ok & (
            df["contrast_p975"].fillna(float("-inf")) >= cfg.MIN_DATE_CONTRAST_P975
        )
        rule = (
            f"LEGACY COMPARISON: valid coverage >= {cfg.MIN_DATE_VALID_COVERAGE:.0%}; "
            f"C{cfg.BACKGROUND_RADIUS_M:g} p97.5 >= {cfg.MIN_DATE_CONTRAST_P975:.3f}"
        )
    else:
        raise ValueError(f"Unknown DATE_SELECTION_MODE: {cfg.DATE_SELECTION_MODE}")

    if cfg.REQUIRE_SPATIAL_CONSISTENCY:
        spatial_field = spatial_landscape_coverage_p25_field(
            cfg.USABLE_CONTRAST_THRESHOLD
        )
        if spatial_field not in df.columns:
            raise ValueError(f"Missing spatial consistency metric: {spatial_field}")
        spatial_ok = (
            df["spatial_cells_evaluable"].fillna(0) > 0
        ) & (
            pd.to_numeric(df[spatial_field], errors="coerce").fillna(float("-inf"))
            >= cfg.MIN_DATE_SPATIAL_USABLE_COVERAGE_P25
        )
        auto = auto & spatial_ok
        rule += (
            f"; 25th percentile across evaluable 1-km cells of usable landscape "
            f"coverage >= {cfg.MIN_DATE_SPATIAL_USABLE_COVERAGE_P25:.0%}"
        )
    else:
        spatial_ok = pd.Series(True, index=df.index)

    df["passes_spatial_consistency"] = spatial_ok
    df["selection_metric"] = selection_metric
    df["selected_auto"] = auto
    df["selected"] = df["selected_auto"]

    include = set(map(str, cfg.FORCE_INCLUDE_DATES))
    exclude = set(map(str, cfg.FORCE_EXCLUDE_DATES))
    if include:
        df.loc[df["date"].isin(include), "selected"] = True
    if exclude:
        df.loc[df["date"].isin(exclude), "selected"] = False
    df["selection_rule"] = rule

    sensitivity_rows = []
    for threshold, eligible_mask in sensitivity_masks.items():
        suffix = coverage_threshold_suffix(threshold)
        sensitivity_rows.append({
            "coverage_threshold": threshold,
            "coverage_threshold_percent": threshold * 100.0,
            "dates_passing_coverage": int(df[f"passes_valid_coverage_{suffix}"].sum()),
            "dates_eligible_for_calibration": int(eligible_mask.sum()),
            "fraction_all_dates_eligible": float(eligible_mask.mean()),
            "top10_dates_usable_coverage": int(
                df[f"diagnostic_top_10pct_usable_coverage_{suffix}"].sum()
            ),
            "top15_dates_usable_coverage": int(
                df[f"diagnostic_top_15pct_usable_coverage_{suffix}"].sum()
            ),
            "top20_dates_usable_coverage": int(
                df[f"diagnostic_top_20pct_usable_coverage_{suffix}"].sum()
            ),
        })
    coverage_sensitivity = pd.DataFrame(sensitivity_rows)

    quantile_levels = [0.50, 0.75, 0.80, 0.85, 0.90, 0.95]
    quantile_metrics = [
        usable_metric,
        usable_valid_metric,
        "contrast_p90",
        "contrast_p95",
        "contrast_p975",
        "contrast_p99",
        *[contrast_fraction_field(t) for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS],
        *[
            contrast_landscape_coverage_field(t)
            for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
        ],
        spatial_landscape_coverage_p25_field(cfg.USABLE_CONTRAST_THRESHOLD),
        f"spatial_cell_{usable_metric}_p50",
        "spatial_cell_p975_p25",
        "spatial_cell_p975_p50",
    ]
    qrows = []
    for metric in dict.fromkeys(quantile_metrics):
        if metric not in df.columns:
            continue
        values = pd.to_numeric(df.loc[calibration_ok, metric], errors="coerce").dropna()
        if values.empty:
            continue
        rec = {
            "metric": metric,
            "n_dates": int(values.size),
            "min": float(values.min()),
            "max": float(values.max()),
            "mean": float(values.mean()),
        }
        for q in quantile_levels:
            rec[f"q{int(q*100):02d}"] = float(values.quantile(q))
        qrows.append(rec)
    quantiles = pd.DataFrame(qrows)

    cfg.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    summary = cfg.OUTPUT_DIR / "date_contrast_summary.csv"
    ranked = cfg.OUTPUT_DIR / "date_contrast_ranked_for_calibration.csv"
    qpath = cfg.OUTPUT_DIR / "empirical_contrast_quantiles.csv"
    selected_path = cfg.OUTPUT_DIR / "selected_usable_contrast_dates.csv"
    legacy_selected_path = cfg.OUTPUT_DIR / "selected_high_contrast_dates.csv"
    coverage_sensitivity_path = cfg.OUTPUT_DIR / "coverage_threshold_sensitivity.csv"

    global_selection_paths = {
        fraction: cfg.OUTPUT_DIR
        / f"selected_global_top{int(round(fraction * 100))}_dates.csv"
        for fraction in global_selection_columns
    }
    annual_selection_paths = {
        n: cfg.OUTPUT_DIR / f"selected_annual_top{n}_dates.csv"
        for n in annual_selection_columns
    }

    df = df.sort_values(
        ["selected", "eligible_for_calibration", selection_metric, "valid_coverage_fraction", "contrast_p975"],
        ascending=[False, False, False, False, False],
        na_position="last",
    ).reset_index(drop=True)
    df.to_csv(summary, index=False)

    ranked_df = df[df["eligible_for_calibration"]].copy().sort_values(
        [selection_metric, "valid_coverage_fraction", "contrast_p975", "date"],
        ascending=[False, False, False, True],
        na_position="last",
    )
    ranked_df.to_csv(ranked, index=False)
    quantiles.to_csv(qpath, index=False)
    coverage_sensitivity.to_csv(coverage_sensitivity_path, index=False)
    df[df["selected"]].to_csv(selected_path, index=False)
    df[df["selected"]].to_csv(legacy_selected_path, index=False)

    for fraction, column in global_selection_columns.items():
        selected_global = _sorted_subset(df, df[column], selection_metric)
        selected_global.to_csv(global_selection_paths[fraction], index=False)

    for n, column in annual_selection_columns.items():
        selected_annual = df[df[column]].copy().sort_values(
            ["year", within_year_rank_col, "date"],
            ascending=[True, True, True],
            na_position="last",
        )
        selected_annual.to_csv(annual_selection_paths[n], index=False)

    print(f"Calibration-eligible dates: {int(calibration_ok.sum())}/{len(df)}")
    print(f"Selection mode: {mode}")
    print(f"Primary usable threshold: C{cfg.BACKGROUND_RADIUS_M:g} >= {cfg.USABLE_CONTRAST_THRESHOLD:.2f}")
    print(f"Ranking metric: {selection_metric}")
    print(f"Selection rule: {rule}")
    print(f"Selected {int(df['selected'].sum())}/{len(df)} dates.")
    print(f"Wrote {summary}")
    print(f"Wrote {ranked}")
    print(f"Wrote {qpath}")
    print(f"Wrote {coverage_sensitivity_path}")
    print(f"Wrote {selected_path}")
    for fraction, path in global_selection_paths.items():
        column = global_selection_columns[fraction]
        print(
            f"Wrote {path} "
            f"({int(df[column].sum())} dates; global top {fraction:.0%} by {selection_metric})"
        )
    for n, path in annual_selection_paths.items():
        column = annual_selection_columns[n]
        n_years = int(df.loc[df[column], "year"].nunique())
        print(
            f"Wrote {path} "
            f"({int(df[column].sum())} dates across {n_years} years; top {n}/year)"
        )

    show_cols = [
        "date",
        "pleiades_footprint_area_km2",
        "pleiades_footprint_fraction_of_aoi",
        "valid_coverage_fraction",
        usable_valid_metric,
        usable_metric,
        "contrast_p95",
        "contrast_p975",
        spatial_landscape_coverage_p25_field(cfg.USABLE_CONTRAST_THRESHOLD),
        f"{usable_metric}_empirical_percentile",
    ]
    show_cols = [c for c in show_cols if c in ranked_df.columns]
    if not ranked_df.empty:
        print("\nTop 20 dates by broad usable-contrast landscape coverage:")
        print(ranked_df[show_cols].head(20).to_string(index=False))


    if mode == "deferred":
        print(
            "\nAutomatic selection is deferred. Review the usable-coverage ranking and "
            "ranking, then change DATE_SELECTION_MODE and rerun Step 03."
        )


if __name__ == "__main__":
    main()
