#!/usr/bin/env python3
# run Landsat contrast screening by Pleiades date

import argparse
import json
import time
import traceback
from datetime import datetime
from pathlib import Path

import pandas as pd

import config as cfg
from tree_contrast_local import (
    acquisition_dates,
    compute_date,
    contrast_fraction_field,
    contrast_landscape_coverage_field,
    load_inputs,
    open_catalog,
    summarize_date_contrast,
    write_geojson,
    write_scene_list,
)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--date", help="Process only one YYYY-MM-DD Pleiades acquisition date.")
    p.add_argument(
        "--force",
        action="store_true",
        help="Reprocess dates even if the output file already exists.",
    )
    return p.parse_args()


def output_path(date_string):
    compact = date_string.replace("-", "")
    return cfg.EXPORT_DIR / f"date_contrast_{compact}.json"


def spatial_cells_path(date_string):
    compact = date_string.replace("-", "")
    return cfg.EXPORT_DIR / f"date_spatial_cells_{compact}.geojson"


def append_log(row, elapsed_seconds, output):
    cfg.LOG_DIR.mkdir(parents=True, exist_ok=True)
    path = cfg.LOG_DIR / "date_processing_log.csv"
    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        **row,
        "elapsed_seconds": round(float(elapsed_seconds), 2),
        "output": str(output),
    }
    pd.DataFrame([record]).to_csv(
        path, mode="a", header=not path.exists(), index=False
    )


def main():
    args = parse_args()
    inputs = load_inputs()
    dates = acquisition_dates(inputs)

    if args.date:
        if args.date not in dates:
            raise ValueError(f"Unknown acquisition date: {args.date}")
        dates = [args.date]
    else:
        stop = cfg.END_INDEX if cfg.END_INDEX is not None else len(dates)
        dates = dates[cfg.START_INDEX:stop]

    cfg.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    cfg.LOG_DIR.mkdir(parents=True, exist_ok=True)

    print(f"Dates to process: {len(dates):,}")
    print(f"Contrast radius: {cfg.BACKGROUND_RADIUS_M:g} m")
    print("Contrast neighbourhood: focal pixel excluded from local median")
    print(
        "Contrast population: all valid Landsat pixels on agricultural land "
        "within each Pleiades footprint"
    )
    print(
        "Diagnostic contrast thresholds: "
        + ", ".join(f"{x:.2f}" for x in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS)
    )
    print(
        f"Reference mask threshold (not selection): {cfg.REFERENCE_CONTRAST_THRESHOLD:.2f}"
    )
    print(f"Temporal window: fixed +/-{cfg.LANDSAT_WINDOW_DAYS} d for every date")

    catalog = open_catalog()
    failures = 0

    for i, date_string in enumerate(dates, start=1):
        out = output_path(date_string)

        if cfg.RESUME and not args.force and out.exists():
            print(f"[{i}/{len(dates)}] {date_string}: skip")
            continue

        if out.exists():
            out.unlink()
        cells_out = spatial_cells_path(date_string)
        if cells_out.exists():
            cells_out.unlink()
        print(f"[{i}/{len(dates)}] {date_string}: processing")
        t0 = time.perf_counter()

        try:
            result = compute_date(catalog, inputs, date_string, keep_arrays=True)
            row = summarize_date_contrast(inputs, result)
            out.write_text(json.dumps(row, indent=2, allow_nan=True), encoding="utf-8")

            # keep all agricultural cells so the export matches the footprint
            if cfg.SAVE_SPATIAL_CELL_SUMMARIES and not result.all_cells.empty:
                write_geojson(result.all_cells, cells_out)

            if cfg.SAVE_SCENE_LISTS:
                write_scene_list(date_string, result.scene_items)
            elapsed = time.perf_counter() - t0
            append_log(row, elapsed, out)

            if row["status"] == "OK":
                usable_t = float(cfg.USABLE_CONTRAST_THRESHOLD)
                usable_valid = row.get(contrast_fraction_field(usable_t), float("nan"))
                usable_landscape = row.get(
                    contrast_landscape_coverage_field(usable_t), float("nan")
                )
                print(
                    f"    footprint={row['pleiades_footprint_fraction_of_aoi']:.1%} of AOI; "
                    f"Landsat valid={row['valid_coverage_fraction']:.1%}; "
                    f"usable C>={usable_t:.2f}: "
                    f"{usable_valid:.1%} of valid pixels / "
                    f"{usable_landscape:.1%} of agricultural footprint; "
                    f"p97.5={row['contrast_p975']:.3f} (diagnostic); "
                    f"cells={row['spatial_cells_evaluable']}/{row['spatial_cells_total']} eval; "
                    f"window=+/-{row['landsat_window_days_used']}d; "
                    f"{elapsed:.1f}s"
                )
            else:
                print(f"    {row['status']}: {row['message']}")

        except Exception as exc:
            failures += 1
            elapsed = time.perf_counter() - t0
            row = {
                "date": date_string,
                "status": "ERROR",
                "message": str(exc),
            }
            append_log(row, elapsed, out)
            print(f"    ERROR after {elapsed:.1f}s: {exc}")
            traceback.print_exc()

    if failures:
        raise SystemExit(
            f"Finished with {failures} failed date(s). See logs/date_processing_log.csv"
        )

    print("Finished successfully.")
    print(f"Per-date metrics: {cfg.EXPORT_DIR.resolve()}")


if __name__ == "__main__":
    main()
