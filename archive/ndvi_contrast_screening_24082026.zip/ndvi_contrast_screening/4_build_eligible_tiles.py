#!/usr/bin/env python3
# build 1 km tile table and add Landsat contrast

import math
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio.features import geometry_mask
from rasterio.windows import from_bounds
from shapely import make_valid
from shapely.geometry import box, mapping

import config as cfg

CLUM_GEOREF_SOURCES = "WORLDFILE,PAM,INTERNAL"


def aligned_grid(geom):
    size = float(cfg.GRID_SIZE_M)
    minx, miny, maxx, maxy = geom.bounds
    x0 = np.floor(minx / size) * size
    x1 = np.ceil(maxx / size) * size
    y0 = np.floor(miny / size) * size
    y1 = np.ceil(maxy / size) * size

    rows = []
    y = y0
    while y < y1:
        x = x0
        while x < x1:
            cell = box(x, y, x + size, y + size)
            if cell.intersects(geom):
                rows.append(
                    {
                        "tile_id": f"T_{int(x)}_{int(y)}",
                        "geometry": cell,
                    }
                )
            x += size
        y += size
    return gpd.GeoDataFrame(rows, geometry="geometry", crs=cfg.GRID_CRS)


def agricultural_fraction(src, geom):
    geom_src = gpd.GeoSeries([geom], crs=cfg.GRID_CRS).to_crs(src.crs).iloc[0]
    if geom_src.is_empty:
        return np.nan

    try:
        window = from_bounds(*geom_src.bounds, transform=src.transform)
        window = window.round_offsets().round_lengths()
        window = window.intersection(
            rasterio.windows.Window(0, 0, src.width, src.height)
        )
    except Exception:
        return np.nan

    if window.width <= 0 or window.height <= 0:
        return np.nan

    arr = src.read(1, window=window, masked=False)
    transform = src.window_transform(window)
    inside = geometry_mask(
        [mapping(geom_src)],
        out_shape=arr.shape,
        transform=transform,
        invert=True,
        all_touched=False,
    )
    valid = inside & np.isfinite(arr)
    if src.nodata is not None:
        valid &= arr != src.nodata

    n = int(valid.sum())
    if n == 0:
        return np.nan
    return float(((arr == float(cfg.CLUM_VALUE)) & valid).sum() / n)


def _tile_id_from_geom(geom):
    size = float(cfg.GRID_SIZE_M)
    minx, miny, _, _ = geom.bounds
    # avoid edge rounding at exact grid lines
    eps = size * 1e-9
    x = math.floor((float(minx) + eps) / size) * size
    y = math.floor((float(miny) + eps) / size) * size
    return f"T_{int(round(x))}_{int(round(y))}"


def _spatial_cells_path(date_string):
    return cfg.EXPORT_DIR / f"date_spatial_cells_{date_string.replace('-', '')}.geojson"


def _load_tile_contrast(date_string):
    path = _spatial_cells_path(date_string)
    if not path.exists():
        if cfg.TILE_CONTRAST_CLASSIFICATION_ENABLED:
            raise FileNotFoundError(f"Missing spatial contrast file: {path}")
        return pd.DataFrame(columns=["tile_id"])

    cells = gpd.read_file(path)
    if cells.empty:
        return pd.DataFrame(columns=["tile_id"])
    cells = cells.to_crs(cfg.GRID_CRS)
    cells = cells[cells.geometry.notna() & ~cells.geometry.is_empty].copy()
    cells["tile_id"] = cells.geometry.map(_tile_id_from_geom)

    metric = str(cfg.TILE_CONTRAST_METRIC)
    required = {
        "spatial_evaluable",
        metric,
        "valid_landsat_pixels",
        "valid_coverage_fraction",
        "usable_contrast_pixels",
        "usable_contrast_fraction_valid",
        "usable_contrast_landscape_coverage",
        "contrast_p50",
        "contrast_p75",
        "contrast_p90",
        "contrast_p95",
        "contrast_p975",
        "cell_area_km2",
    }
    missing = sorted(required - set(cells.columns))
    if missing:
        raise ValueError(f"Missing columns in {path.name}: {', '.join(missing)}")

    # keep the best represented duplicate
    cells["cell_area_km2"] = pd.to_numeric(cells["cell_area_km2"], errors="coerce")
    cells["valid_landsat_pixels"] = pd.to_numeric(
        cells["valid_landsat_pixels"], errors="coerce"
    )
    cells = cells.sort_values(
        ["tile_id", "cell_area_km2", "valid_landsat_pixels"],
        ascending=[True, False, False],
        na_position="last",
    ).drop_duplicates("tile_id", keep="first")

    cells["tile_contrast_metric_value"] = pd.to_numeric(cells[metric], errors="coerce")
    rename = {
        "spatial_evaluable": "tile_contrast_evaluable",
        "valid_landsat_pixels": "tile_valid_landsat_pixels",
        "valid_coverage_fraction": "tile_valid_coverage_fraction",
        "usable_contrast_pixels": "tile_usable_contrast_pixels",
        "usable_contrast_fraction_valid": "tile_usable_contrast_fraction_valid",
        "usable_contrast_landscape_coverage": "tile_usable_contrast_landscape_coverage",
        "contrast_p50": "tile_contrast_p50",
        "contrast_p75": "tile_contrast_p75",
        "contrast_p90": "tile_contrast_p90",
        "contrast_p95": "tile_contrast_p95",
        "contrast_p975": "tile_contrast_p975",
        "cell_area_km2": "tile_contrast_cell_area_km2",
    }
    keep = ["tile_id", "tile_contrast_metric_value", *rename.keys()]
    out = cells[keep].rename(columns=rename).copy()
    out["tile_contrast_metric"] = metric
    out["tile_contrast_threshold"] = float(cfg.MIN_TILE_CONTRAST_METRIC_VALUE)
    out["tile_contrast_evaluable"] = (
        out["tile_contrast_evaluable"].fillna(False).astype(bool)
    )
    out["tile_contrast_metric_value"] = pd.to_numeric(
        out["tile_contrast_metric_value"], errors="coerce"
    )
    out["tile_contrast_pass"] = (
        out["tile_contrast_evaluable"]
        & out["tile_contrast_metric_value"].notna()
        & (
            out["tile_contrast_metric_value"]
            >= float(cfg.MIN_TILE_CONTRAST_METRIC_VALUE)
        )
    )
    return pd.DataFrame(out)


def main():
    selected_path = cfg.OUTPUT_DIR / cfg.PLEIADES_DATE_SELECTION_FILE
    if not selected_path.exists():
        raise FileNotFoundError(f"Missing selected dates: {selected_path}")

    selected = pd.read_csv(selected_path, dtype={"date": str})
    selected_dates = set(selected["date"].astype(str))
    if not selected_dates:
        raise RuntimeError("No usable-contrast dates are currently selected.")

    footprints = gpd.read_file(
        cfg.FOOTPRINTS_FILE, layer=cfg.FOOTPRINTS_LAYER
    ).to_crs(cfg.GRID_CRS)
    footprints = footprints[footprints.geometry.notna()].copy()
    footprints["geometry"] = footprints.geometry.map(make_valid)
    footprints[cfg.DATE_FIELD] = pd.to_datetime(
        footprints[cfg.DATE_FIELD], errors="raise"
    ).dt.strftime("%Y-%m-%d")
    footprints = footprints[
        footprints[cfg.DATE_FIELD].isin(selected_dates)
    ].copy()

    if footprints.empty:
        raise RuntimeError("Selected dates do not match the prepared Pleiades footprints.")

    print(
        "Tile eligibility: "
        f"Pleiades coverage >= {cfg.MIN_PLEIADES_COVERAGE:.0%}; "
        f"agricultural land >= {cfg.MIN_AGRICULTURAL_FRACTION:.0%}"
    )

    outputs = []
    # agricultural fraction does not change between dates
    agricultural_fraction_cache = {}

    with rasterio.Env(GDAL_GEOREF_SOURCES=CLUM_GEOREF_SOURCES):
        with rasterio.open(cfg.CLUM_RASTER) as clum:
            for date_string, rows in footprints.groupby(cfg.DATE_FIELD):
                coverage = make_valid(rows.geometry.union_all())
                grid = aligned_grid(coverage)
                grid["date"] = date_string
                grid["year"] = int(date_string[:4])

                grid["pleiades_coverage_fraction"] = [
                    float(cell.intersection(coverage).area / cell.area)
                    for cell in grid.geometry
                ]

                print(
                    f"{date_string}: checking agricultural land for "
                    f"{len(grid):,} candidate tiles"
                )
                agri_values = []
                for tile_id, cell in zip(grid["tile_id"], grid.geometry):
                    if tile_id not in agricultural_fraction_cache:
                        agricultural_fraction_cache[tile_id] = agricultural_fraction(clum, cell)
                    agri_values.append(agricultural_fraction_cache[tile_id])
                grid["agricultural_fraction"] = agri_values

                # Primary tile eligibility requires the configured minimum
                # agricultural fraction (currently 0.90 = 90%). The full
                # agricultural_fraction value is retained in the output so the
                # stricter 0.95 sensitivity threshold can be applied downstream.
                agricultural_ok = (
                    grid["agricultural_fraction"].fillna(0.0)
                    >= float(cfg.MIN_AGRICULTURAL_FRACTION)
                )

                grid["eligible"] = (
                    grid["pleiades_coverage_fraction"]
                    >= cfg.MIN_PLEIADES_COVERAGE - 1e-9
                ) & agricultural_ok

                eligible = grid[grid["eligible"]].copy()

                if cfg.TILE_CONTRAST_CLASSIFICATION_ENABLED:
                    contrast = _load_tile_contrast(date_string)
                    eligible = eligible.merge(contrast, on="tile_id", how="left")
                    eligible = gpd.GeoDataFrame(
                        eligible, geometry="geometry", crs=cfg.GRID_CRS
                    )
                    eligible["tile_contrast_evaluable"] = (
                        eligible["tile_contrast_evaluable"].fillna(False).astype(bool)
                    )
                    eligible["tile_contrast_pass"] = (
                        eligible["tile_contrast_pass"].fillna(False).astype(bool)
                    )
                    n_eval = int(eligible["tile_contrast_evaluable"].sum())
                    n_pass = int(eligible["tile_contrast_pass"].sum())
                    print(
                        f"    retained {len(eligible):,}/{len(grid):,}; "
                        f"tile contrast evaluable={n_eval:,}, pass={n_pass:,}"
                    )
                else:
                    print(f"    retained {len(eligible):,}/{len(grid):,}")

                outputs.append(eligible)

    if not outputs:
        raise RuntimeError("No eligible 1-km tiles were produced.")

    merged = gpd.GeoDataFrame(
        pd.concat(outputs, ignore_index=True),
        geometry="geometry",
        crs=cfg.GRID_CRS,
    )

    cfg.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    gpkg = cfg.OUTPUT_DIR / "eligible_tiles_selected_dates.gpkg"
    csv = cfg.OUTPUT_DIR / "eligible_tiles_selected_dates.csv"

    if gpkg.exists():
        gpkg.unlink()
    merged.to_file(gpkg, layer="eligible_tiles", driver="GPKG")
    merged.drop(columns="geometry").to_csv(csv, index=False)

    availability = (
        merged[["tile_id", "date"]]
        .drop_duplicates()
        .assign(available=1)
        .pivot_table(
            index="tile_id",
            columns="date",
            values="available",
            fill_value=0,
            aggfunc="max",
        )
        .reset_index()
    )
    availability.to_csv(
        cfg.OUTPUT_DIR / "tile_date_availability.csv", index=False
    )

    print(f"Date selection source: {selected_path.name}")
    print(f"Unique spatial tiles: {merged['tile_id'].nunique():,}")
    print(f"Eligible tile-date combinations: {len(merged):,}")
    if cfg.TILE_CONTRAST_CLASSIFICATION_ENABLED:
        print(
            "Tile contrast is attached but NOT used as a hard Step-06 filter: "
            f"{cfg.TILE_CONTRAST_METRIC} >= "
            f"{float(cfg.MIN_TILE_CONTRAST_METRIC_VALUE):.3f} counts as a tile/date pass."
        )
    print(f"Wrote {gpkg}")
    print(f"Wrote {csv}")


if __name__ == "__main__":
    main()
