#!/usr/bin/env python3
# summarise date and tile availability by year

import pandas as pd

import config as cfg


def main():
    dates_path = cfg.OUTPUT_DIR / cfg.PLEIADES_DATE_SELECTION_FILE
    tiles_path = cfg.OUTPUT_DIR / "eligible_tiles_selected_dates.csv"

    if not dates_path.exists():
        raise FileNotFoundError(dates_path)
    if not tiles_path.exists():
        raise FileNotFoundError(tiles_path)

    dates = pd.read_csv(dates_path, dtype={"date": str})
    dates["year"] = dates["date"].str[:4].astype(int)

    tiles = pd.read_csv(tiles_path, dtype={"date": str})
    tiles["year"] = tiles["date"].str[:4].astype(int)

    dates_by_year = (
        dates.groupby("year")
        .agg(
            selected_dates=("date", "nunique"),
            dates=("date", lambda x: ",".join(sorted(set(x)))),
        )
        .reset_index()
    )
    dates_by_year.to_csv(cfg.OUTPUT_DIR / "selected_dates_by_year.csv", index=False)

    tile_year = tiles[["tile_id", "year"]].drop_duplicates()
    tile_counts = (
        tile_year.groupby("year")["tile_id"]
        .nunique()
        .rename("eligible_unique_tiles")
        .reset_index()
    )
    tile_counts.to_csv(cfg.OUTPUT_DIR / "eligible_tiles_by_year.csv", index=False)

    years = sorted(tile_year["year"].unique())
    tile_sets = {
        y: set(tile_year.loc[tile_year["year"] == y, "tile_id"])
        for y in years
    }
    pair_rows = []
    for i, y1 in enumerate(years):
        for y2 in years[i + 1 :]:
            pair_rows.append(
                {
                    "year_1": y1,
                    "year_2": y2,
                    "common_tiles": len(tile_sets[y1] & tile_sets[y2]),
                }
            )

    pd.DataFrame(pair_rows).to_csv(
        cfg.OUTPUT_DIR / "pairwise_common_tile_counts.csv", index=False
    )

    print(f"Date selection source: {dates_path.name}")
    print("Selected dates by year:")
    print(dates_by_year.to_string(index=False))
    print("\\nEligible unique tiles by year:")
    print(tile_counts.to_string(index=False))


if __name__ == "__main__":
    main()
