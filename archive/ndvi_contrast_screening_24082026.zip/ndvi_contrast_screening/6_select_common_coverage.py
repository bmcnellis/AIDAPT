#!/usr/bin/env python3
# select common tiles for the longitudinal comparisons

import math

import geopandas as gpd
import numpy as np
import pandas as pd

import config as cfg


def _scenario_slug(name):
    return "".join(c if c.isalnum() or c in "_-" else "_" for c in str(name))


def _join_dates(values):
    return ",".join(sorted(set(values.dropna().astype(str))))


def _join_dates_where(group, mask_col):
    mask = group[mask_col].fillna(False).astype(bool)
    return _join_dates(group.loc[mask, "date"])


def _best_date(group, metric_col):
    values = pd.to_numeric(group[metric_col], errors="coerce")
    evaluable = group["tile_contrast_evaluable"].fillna(False).astype(bool)
    valid = evaluable & values.notna()
    if not valid.any():
        return ""
    candidates = group.loc[valid, ["date", metric_col]].copy()
    candidates[metric_col] = pd.to_numeric(candidates[metric_col], errors="coerce")
    candidates = candidates.sort_values(
        [metric_col, "date"], ascending=[False, True], na_position="last"
    )
    return str(candidates.iloc[0]["date"])


def _build_tile_year_table(tiles):
    contrast_enabled = bool(cfg.TILE_CONTRAST_CLASSIFICATION_ENABLED)
    rows = []

    for (tile_id, year), group in tiles.groupby(["tile_id", "year"], sort=True):
        rec = {
            "tile_id": str(tile_id),
            "year": int(year),
            "acceptable_dates": _join_dates(group["date"]),
            "n_acceptable_dates": int(group["date"].nunique()),
        }

        if contrast_enabled:
            evaluable = group["tile_contrast_evaluable"].fillna(False).astype(bool)
            passed = group["tile_contrast_pass"].fillna(False).astype(bool)
            metric = pd.to_numeric(group["tile_contrast_metric_value"], errors="coerce")
            metric_evaluable = metric[evaluable & metric.notna()]

            rec.update(
                {
                    "contrast_evaluable_dates": _join_dates_where(
                        group, "tile_contrast_evaluable"
                    ),
                    "n_contrast_evaluable_dates": int(
                        group.loc[evaluable, "date"].nunique()
                    ),
                    "contrast_pass_dates": _join_dates_where(group, "tile_contrast_pass"),
                    "n_contrast_pass_dates": int(group.loc[passed, "date"].nunique()),
                    "tile_year_contrast_evaluable": bool(evaluable.any()),
                    "tile_year_contrast_pass": bool(passed.any()),
                    "best_contrast_date": _best_date(group, "tile_contrast_metric_value"),
                    "year_best_tile_contrast": (
                        float(metric_evaluable.max()) if not metric_evaluable.empty else np.nan
                    ),
                    "year_median_tile_contrast": (
                        float(metric_evaluable.median()) if not metric_evaluable.empty else np.nan
                    ),
                }
            )

        rows.append(rec)

    return pd.DataFrame(rows)


def _status_for_pass_years(n_pass, n_required):
    if n_required <= 0:
        return "Weak", 2, 0
    good_min = max(
        1,
        int(math.ceil(float(cfg.TILE_CONTRAST_GOOD_MIN_YEAR_FRACTION) * n_required - 1e-12)),
    )
    if n_pass >= n_required:
        return "Strong", 0, good_min
    if n_pass >= good_min:
        return "Good", 1, good_min
    return "Weak", 2, good_min


def _write_gpkg_csv(
    gdf,
    csv_path,
    gpkg_path,
    layer,
):
    if gpkg_path.exists():
        gpkg_path.unlink()
    if gdf.empty:
        pd.DataFrame(columns=[c for c in gdf.columns if c != "geometry"]).to_csv(
            csv_path, index=False
        )
        return
    gdf.to_file(gpkg_path, layer=layer, driver="GPKG")
    gdf.drop(columns="geometry").to_csv(csv_path, index=False)


def main():
    tiles_path = cfg.OUTPUT_DIR / "eligible_tiles_selected_dates.gpkg"
    dates_path = cfg.OUTPUT_DIR / cfg.PLEIADES_DATE_SELECTION_FILE

    if not tiles_path.exists():
        raise FileNotFoundError(tiles_path)
    if not dates_path.exists():
        raise FileNotFoundError(dates_path)

    tiles = gpd.read_file(tiles_path, layer="eligible_tiles")
    if tiles.empty:
        raise RuntimeError("eligible_tiles_selected_dates.gpkg contains no tiles.")

    tiles["date"] = tiles["date"].astype(str)
    tiles["year"] = tiles["date"].str[:4].astype(int)

    contrast_enabled = bool(cfg.TILE_CONTRAST_CLASSIFICATION_ENABLED)
    if contrast_enabled:
        required_contrast_cols = {
            "tile_contrast_evaluable",
            "tile_contrast_pass",
            "tile_contrast_metric_value",
        }
        missing = sorted(required_contrast_cols - set(tiles.columns))
        if missing:
            raise ValueError(f"Missing tile contrast columns: {', '.join(missing)}")

    selected = pd.read_csv(dates_path, dtype={"date": str})
    selected["year"] = selected["date"].str[:4].astype(int)

    selected_date_set = set(selected["date"].astype(str))
    tile_date_set = set(tiles["date"].astype(str))
    unexpected_tile_dates = sorted(tile_date_set - selected_date_set)
    if unexpected_tile_dates:
        preview = ", ".join(unexpected_tile_dates[:5])
        suffix = " ..." if len(unexpected_tile_dates) > 5 else ""
        raise RuntimeError(f"Tile dates do not match selected dates: {preview}{suffix}")

    selected_dates_by_year = {
        int(year): sorted(group["date"].astype(str).unique())
        for year, group in selected.groupby("year")
    }

    cfg.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    summary_rows = []

    tile_geometry = (
        tiles[["tile_id", "geometry"]]
        .drop_duplicates(subset=["tile_id"])
        .set_index("tile_id")["geometry"]
    )

    tile_year_dates = _build_tile_year_table(tiles)

    for scenario_name, required_years_raw in cfg.COMMON_COVERAGE_SCENARIOS.items():
        slug = _scenario_slug(scenario_name)
        required_years = tuple(sorted({int(y) for y in required_years_raw}))
        if not required_years:
            print(f"{scenario_name}: skipped (no required years configured)")
            continue

        available_years = set(tile_year_dates["year"].unique())
        missing_years = [y for y in required_years if y not in available_years]

        year_sets = {
            year: set(
                tile_year_dates.loc[
                    tile_year_dates["year"] == year, "tile_id"
                ].astype(str)
            )
            for year in required_years
        }

        if missing_years:
            common_ids = set()
            status = "MISSING_REQUIRED_YEAR"
        else:
            common_ids = set.intersection(*(year_sets[y] for y in required_years))
            status = "OK" if common_ids else "NO_SPATIAL_INTERSECTION"

        support = tile_year_dates[
            tile_year_dates["tile_id"].astype(str).isin(common_ids)
            & tile_year_dates["year"].isin(required_years)
        ].copy()
        support = support.sort_values(["tile_id", "year"])
        support.to_csv(
            cfg.OUTPUT_DIR / f"common_coverage_{slug}_tile_year_dates.csv",
            index=False,
        )

        if common_ids:
            common = gpd.GeoDataFrame(
                {"tile_id": sorted(common_ids)},
                geometry=[tile_geometry.loc[t] for t in sorted(common_ids)],
                crs=tiles.crs,
            )
            common["scenario"] = scenario_name
            common["required_years"] = ",".join(map(str, required_years))
            common["n_required_years"] = len(required_years)

            count_matrix = support.pivot(
                index="tile_id", columns="year", values="n_acceptable_dates"
            ).fillna(0).astype(int)
            for year in required_years:
                series = count_matrix[year] if year in count_matrix.columns else pd.Series(dtype=int)
                common[f"n_dates_{year}"] = (
                    common["tile_id"].map(series).fillna(0).astype(int)
                )

            if contrast_enabled:
                pass_matrix = support.pivot(
                    index="tile_id", columns="year", values="tile_year_contrast_pass"
                ).fillna(False).astype(bool)
                eval_matrix = support.pivot(
                    index="tile_id", columns="year", values="tile_year_contrast_evaluable"
                ).fillna(False).astype(bool)
                best_matrix = support.pivot(
                    index="tile_id", columns="year", values="year_best_tile_contrast"
                )

                for year in required_years:
                    pass_series = (
                        pass_matrix[year] if year in pass_matrix.columns else pd.Series(dtype=bool)
                    )
                    eval_series = (
                        eval_matrix[year] if year in eval_matrix.columns else pd.Series(dtype=bool)
                    )
                    best_series = (
                        best_matrix[year] if year in best_matrix.columns else pd.Series(dtype=float)
                    )
                    common[f"contrast_pass_{year}"] = (
                        common["tile_id"].map(pass_series).fillna(False).astype(bool)
                    )
                    common[f"contrast_evaluable_{year}"] = (
                        common["tile_id"].map(eval_series).fillna(False).astype(bool)
                    )
                    common[f"best_tile_contrast_{year}"] = pd.to_numeric(
                        common["tile_id"].map(best_series), errors="coerce"
                    )

                pass_cols = [f"contrast_pass_{y}" for y in required_years]
                eval_cols = [f"contrast_evaluable_{y}" for y in required_years]
                best_cols = [f"best_tile_contrast_{y}" for y in required_years]
                common["n_contrast_pass_years"] = common[pass_cols].sum(axis=1).astype(int)
                common["n_contrast_evaluable_years"] = common[eval_cols].sum(axis=1).astype(int)
                common["contrast_pass_fraction_required_years"] = (
                    common["n_contrast_pass_years"] / len(required_years)
                )
                common["median_year_best_tile_contrast"] = common[best_cols].median(
                    axis=1, skipna=True
                )
                common["minimum_year_best_tile_contrast"] = common[best_cols].min(
                    axis=1, skipna=True
                )
                common["mean_year_best_tile_contrast"] = common[best_cols].mean(
                    axis=1, skipna=True
                )

                statuses = common["n_contrast_pass_years"].map(
                    lambda n: _status_for_pass_years(int(n), len(required_years))
                )
                common["contrast_status"] = statuses.map(lambda x: x[0])
                common["contrast_status_rank"] = statuses.map(lambda x: x[1]).astype(int)
                common["good_min_pass_years"] = statuses.map(lambda x: x[2]).astype(int)
                common["tile_contrast_metric"] = str(cfg.TILE_CONTRAST_METRIC)
                common["tile_contrast_threshold"] = float(
                    cfg.MIN_TILE_CONTRAST_METRIC_VALUE
                )
                common["primary_quality_eligible"] = common["contrast_status"].isin(
                    ["Strong", "Good"]
                )

                common = common.sort_values(
                    [
                        "contrast_status_rank",
                        "n_contrast_pass_years",
                        "n_contrast_evaluable_years",
                        "median_year_best_tile_contrast",
                        "minimum_year_best_tile_contrast",
                        "tile_id",
                    ],
                    ascending=[True, False, False, False, False, True],
                    na_position="last",
                ).reset_index(drop=True)
                common["overall_quality_rank"] = np.arange(1, len(common) + 1)

                quality_pool = common[common["primary_quality_eligible"]].copy()
                target_n = max(0, int(cfg.TARGET_PRIMARY_TILES))
                primary = quality_pool.head(target_n).copy()
                primary["selection_group"] = "primary"
                primary["selection_rank"] = np.arange(1, len(primary) + 1)

                reserve_n = max(0, int(cfg.TARGET_RESERVE_TILES))
                reserve_candidates = quality_pool.iloc[len(primary):].copy()
                if bool(cfg.ALLOW_WEAK_TILES_AS_RESERVE) and len(reserve_candidates) < reserve_n:
                    weak = common[common["contrast_status"].eq("Weak")].copy()
                    reserve_candidates = pd.concat(
                        [reserve_candidates, weak], ignore_index=True
                    )
                    reserve_candidates = gpd.GeoDataFrame(
                        reserve_candidates, geometry="geometry", crs=common.crs
                    )
                reserve = reserve_candidates.head(reserve_n).copy()
                reserve["selection_group"] = "reserve"
                reserve["selection_rank"] = np.arange(1, len(reserve) + 1)

                common["selection_group"] = "not_selected"
                common.loc[
                    common["tile_id"].isin(set(primary["tile_id"])), "selection_group"
                ] = "primary"
                common.loc[
                    common["tile_id"].isin(set(reserve["tile_id"])), "selection_group"
                ] = "reserve"
            else:
                common["contrast_status"] = "Not_classified"
                common["primary_quality_eligible"] = True
                common["overall_quality_rank"] = np.arange(1, len(common) + 1)
                target_n = max(0, int(cfg.TARGET_PRIMARY_TILES))
                primary = common.head(target_n).copy()
                primary["selection_group"] = "primary"
                primary["selection_rank"] = np.arange(1, len(primary) + 1)
                reserve = common.iloc[len(primary): len(primary) + max(0, int(cfg.TARGET_RESERVE_TILES))].copy()
                reserve["selection_group"] = "reserve"
                reserve["selection_rank"] = np.arange(1, len(reserve) + 1)
                common["selection_group"] = "not_selected"
                common.loc[common["tile_id"].isin(set(primary["tile_id"])), "selection_group"] = "primary"
                common.loc[common["tile_id"].isin(set(reserve["tile_id"])), "selection_group"] = "reserve"

            _write_gpkg_csv(
                common,
                cfg.OUTPUT_DIR / f"common_coverage_{slug}.csv",
                cfg.OUTPUT_DIR / f"common_coverage_{slug}.gpkg",
                "common_tiles",
            )
            _write_gpkg_csv(
                primary,
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_primary.csv",
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_primary.gpkg",
                "primary_tiles",
            )
            _write_gpkg_csv(
                reserve,
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_reserve.csv",
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_reserve.gpkg",
                "reserve_tiles",
            )
        else:
            common = gpd.GeoDataFrame(
                columns=["tile_id", "scenario", "required_years", "n_required_years", "geometry"],
                geometry="geometry",
                crs=tiles.crs,
            )
            primary = common.copy()
            reserve = common.copy()
            _write_gpkg_csv(
                common,
                cfg.OUTPUT_DIR / f"common_coverage_{slug}.csv",
                cfg.OUTPUT_DIR / f"common_coverage_{slug}.gpkg",
                "common_tiles",
            )
            _write_gpkg_csv(
                primary,
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_primary.csv",
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_primary.gpkg",
                "primary_tiles",
            )
            _write_gpkg_csv(
                reserve,
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_reserve.csv",
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_reserve.gpkg",
                "reserve_tiles",
            )

        per_year_counts = {y: len(year_sets[y]) for y in required_years}
        status_counts = (
            common["contrast_status"].value_counts().to_dict()
            if "contrast_status" in common.columns else {}
        )
        strong_n = int(status_counts.get("Strong", 0))
        good_n = int(status_counts.get("Good", 0))
        weak_n = int(status_counts.get("Weak", 0))
        primary_n = int(len(primary))
        target_n = max(0, int(cfg.TARGET_PRIMARY_TILES))

        if contrast_enabled and not common.empty:
            pass_year_distribution = (
                common.groupby(["n_contrast_pass_years", "contrast_status"], as_index=False)
                .size()
                .rename(columns={"size": "tile_count"})
                .sort_values("n_contrast_pass_years", ascending=False)
            )
            pass_year_distribution["scenario"] = scenario_name
            pass_year_distribution["n_required_years"] = len(required_years)
            pass_year_distribution["required_years"] = ",".join(map(str, required_years))
            pass_year_distribution.to_csv(
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_contrast_pass_year_counts.csv",
                index=False,
            )
        elif contrast_enabled:
            pd.DataFrame(
                columns=[
                    "n_contrast_pass_years", "contrast_status", "tile_count",
                    "scenario", "n_required_years", "required_years",
                ]
            ).to_csv(
                cfg.OUTPUT_DIR / f"common_coverage_{slug}_contrast_pass_year_counts.csv",
                index=False,
            )

        summary_rows.append(
            {
                "scenario": scenario_name,
                "required_years": ",".join(map(str, required_years)),
                "n_required_years": len(required_years),
                "status": status,
                "missing_required_years": ",".join(map(str, missing_years)),
                "common_tiles": len(common_ids),
                "common_coverage_km2": float(
                    len(common_ids) * (float(cfg.GRID_SIZE_M) ** 2) / 1_000_000.0
                ),
                "strong_tiles": strong_n,
                "good_tiles": good_n,
                "weak_tiles": weak_n,
                "strong_plus_good_tiles": strong_n + good_n,
                "primary_target_tiles": target_n,
                "primary_selected_tiles": primary_n,
                "primary_shortfall_tiles": max(0, target_n - primary_n),
                "reserve_selected_tiles": int(len(reserve)),
                "tile_contrast_metric": str(cfg.TILE_CONTRAST_METRIC) if contrast_enabled else "",
                "tile_contrast_threshold": (
                    float(cfg.MIN_TILE_CONTRAST_METRIC_VALUE) if contrast_enabled else np.nan
                ),
                "good_min_year_fraction": (
                    float(cfg.TILE_CONTRAST_GOOD_MIN_YEAR_FRACTION) if contrast_enabled else np.nan
                ),
                "eligible_tiles_by_required_year": ";".join(
                    f"{y}:{per_year_counts[y]}" for y in required_years
                ),
                "selected_acceptable_dates_by_required_year": ";".join(
                    f"{y}:{len(selected_dates_by_year.get(y, []))}" for y in required_years
                ),
                "date_selection_source": dates_path.name,
            }
        )

        if missing_years:
            print(
                f"{scenario_name}: no result; required year(s) absent from eligible "
                f"selected-date tiles: {', '.join(map(str, missing_years))}"
            )
        elif not common_ids:
            print(
                f"{scenario_name}: 0 common 1-km tiles across "
                f"{', '.join(map(str, required_years))}"
            )
        elif contrast_enabled:
            print(
                f"{scenario_name}: {len(common_ids):,} common tiles; "
                f"Strong={strong_n:,}, Good={good_n:,}, Weak={weak_n:,}; "
                f"primary={primary_n:,}/{target_n:,}, reserve={len(reserve):,}"
            )
        else:
            print(
                f"{scenario_name}: {len(common_ids):,} common 1-km tiles "
                f"across {', '.join(map(str, required_years))}"
            )

    summary = pd.DataFrame(summary_rows)
    summary_path = cfg.OUTPUT_DIR / "common_coverage_summary.csv"
    summary.to_csv(summary_path, index=False)

    print(f"Date selection source: {dates_path.name}")
    print(f"Wrote {summary_path}")


if __name__ == "__main__":
    main()
