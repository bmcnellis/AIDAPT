# Pleiades contrast screening and tile selection

Code used to screen Pleiades acquisition dates with Landsat NDVI contrast and select 1km tiles.

The main settings are in `config.py`. The current configuration uses a ±8-day Landsat window, a usable contrast threshold of `C30 >= 0.03`, at least 70% valid Landsat coverage at the date-screening stage, 100% Pleiades coverage for each 1-km tile, and at least 90% agricultural land within each selected tile. A stricter 95% agricultural-land threshold is retained as a sensitivity analysis. C30 is calculated as focal-pixel NDVI minus the median NDVI of neighbouring pixels within the 30 m radius and the focal pixel is excluded from the neighbourhood median.
