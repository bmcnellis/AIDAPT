# shared functions for the contrast screening scripts

import json
import math
import re
import time
import warnings
from dataclasses import dataclass
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import geopandas as gpd
from affine import Affine
import numpy as np
import pandas as pd
import rasterio
import planetary_computer
from odc import stac
from pystac import Item
from pystac_client import Client
from rasterio.features import geometry_mask, rasterize
from rasterio.warp import Resampling, reproject
from scipy.ndimage import generic_filter
from shapely import make_valid
from shapely.geometry import box, mapping, shape
from shapely.geometry.base import BaseGeometry

import config as cfg

REQUIRED_ASSETS = ("red", "nir08", "qa_pixel", "qa_radsat")
# Landsat QA bits 0-5: fill, cloud/cirrus, shadow and snow.
QA_BAD_BITS_0_TO_5 = 0b111111


@dataclass
class Inputs:
    aoi: BaseGeometry
    footprints: gpd.GeoDataFrame


@dataclass
class DateResult:
    date: str
    status: str
    message: str
    scene_items: list[Item]
    selected: gpd.GeoDataFrame
    all_cells: gpd.GeoDataFrame
    ndvi: np.ndarray | None = None
    contrast: np.ndarray | None = None
    high: np.ndarray | None = None
    transform: Affine | None = None
    landsat_window_days_used: int | None = None
    crs: str = cfg.GRID_CRS

    @property
    def scene_count(self):
        return len(self.scene_items)

    @property
    def selected_count(self):
        return len(self.selected)


def load_inputs():
    for path in (cfg.AOI_FILE, cfg.FOOTPRINTS_FILE, cfg.CLUM_RASTER):
        if not Path(path).exists():
            raise FileNotFoundError(f"Required input not found: {Path(path).resolve()}")

    aoi_gdf = gpd.read_file(cfg.AOI_FILE, layer=cfg.AOI_LAYER)
    footprints = gpd.read_file(cfg.FOOTPRINTS_FILE, layer=cfg.FOOTPRINTS_LAYER)

    if cfg.DATE_FIELD not in footprints.columns:
        raise RuntimeError(f"Missing footprint date field: {cfg.DATE_FIELD}")

    aoi_gdf = aoi_gdf.to_crs(cfg.GRID_CRS)
    footprints = footprints.to_crs(cfg.GRID_CRS)
    footprints = footprints[footprints.geometry.notna()].copy()
    footprints["geometry"] = footprints.geometry.map(make_valid)
    footprints[cfg.DATE_FIELD] = pd.to_datetime(
        footprints[cfg.DATE_FIELD], errors="raise"
    ).dt.strftime("%Y-%m-%d")

    aoi = make_valid(aoi_gdf.geometry.union_all())
    footprints = footprints[footprints.intersects(aoi)].copy()
    if footprints.empty:
        raise RuntimeError("No footprints intersect the AOI.")

    return Inputs(aoi=aoi, footprints=footprints)


def acquisition_dates(inputs):
    values = sorted(inputs.footprints[cfg.DATE_FIELD].dropna().astype(str).unique())
    return [d for d in values if cfg.START_DATE <= d < cfg.END_DATE]


def geometry_for_date(inputs, date_string):
    rows = inputs.footprints[inputs.footprints[cfg.DATE_FIELD] == date_string]
    geom = make_valid(rows.geometry.union_all().intersection(inputs.aoi))
    if geom.is_empty:
        raise RuntimeError(f"Footprints for {date_string} do not overlap the AOI.")
    return geom


def open_catalog():
    return Client.open(cfg.STAC_URL, modifier=planetary_computer.sign_inplace)


def _is_requested_landsat_item(item):
    if not item.id.startswith(tuple(cfg.LANDSAT_ID_PREFIXES)):
        return False
    if cfg.REQUIRE_TIER1:
        category = item.properties.get("landsat:collection_category")
        if category is not None:
            if str(category).upper() != "T1":
                return False
        elif re.search(r"(?:^|_)T1(?:_|$)", item.id, flags=re.IGNORECASE) is None:
            # T1 is not always the final suffix in the STAC item ID.
            return False
    return all(name in item.assets for name in REQUIRED_ASSETS)


def search_landsat(
    catalog,
    date_string,
    geom_3577,
    window_days=None,
):
    center = date.fromisoformat(date_string)
    if window_days is None:
        window_days = int(cfg.LANDSAT_WINDOW_DAYS)
    start = center - timedelta(days=int(window_days))
    end = center + timedelta(days=int(window_days))

    geom_wgs84 = gpd.GeoSeries([geom_3577], crs=cfg.GRID_CRS).to_crs("EPSG:4326").iloc[0]

    # bbox first, then filter the returned footprints
    bbox_wgs84 = tuple(float(v) for v in geom_wgs84.bounds)
    search = catalog.search(
        collections=[cfg.STAC_COLLECTION],
        bbox=bbox_wgs84,
        datetime=f"{start.isoformat()}/{end.isoformat()}",
    )

    items = []
    for item in search.items():
        if not _is_requested_landsat_item(item):
            continue
        if item.geometry is not None:
            try:
                item_geom = make_valid(shape(item.geometry))
                if not item_geom.intersects(geom_wgs84):
                    continue
            except Exception:
                # keep the bbox match if footprint parsing fails
                pass
        items.append(item)

    items.sort(key=lambda item: (item.datetime.timestamp() if item.datetime else float("-inf"), item.id))
    return items


def _safe_asset_href(item, asset_name):
    # drop temporary query credentials from the asset URL
    if asset_name not in item.assets:
        return ""
    parts = urlsplit(item.assets[asset_name].href)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))


def scene_inventory(items, reference_date=None):
    rows = []
    ref = date.fromisoformat(reference_date) if reference_date else None
    for item in items:
        item_date = item.datetime.date() if item.datetime else None
        rows.append(
            {
                "item_id": item.id,
                "datetime": item.datetime.isoformat() if item.datetime else "",
                "days_from_pleiades": (
                    (item_date - ref).days if ref is not None and item_date is not None else np.nan
                ),
                "cloud_cover": item.properties.get("eo:cloud_cover"),
                "collection_category": item.properties.get("landsat:collection_category"),
                "red_href": _safe_asset_href(item, "red"),
                "nir_href": _safe_asset_href(item, "nir08"),
            }
        )
    return pd.DataFrame(rows)


def load_landsat_stack(items, geom_3577):
    minx, miny, maxx, maxy = geom_3577.bounds
    ds = stac.load(
        items,
        bands=list(REQUIRED_ASSETS),
        crs=cfg.GRID_CRS,
        resolution=cfg.SCALE_M,
        x=(minx, maxx),
        y=(miny, maxy),
        groupby="id",
        resampling={name: "nearest" for name in REQUIRED_ASSETS},
        # load lazily; pixels are read in chunks below
        chunks={"x": cfg.PROCESSING_TILE_SIZE_PX, "y": cfg.PROCESSING_TILE_SIZE_PX},
        fail_on_error=True,
    )
    return ds


def grid_transform(ds):
    try:
        return ds.odc.geobox.transform
    except Exception:
        # fallback if the geobox is unavailable
        x = np.asarray(ds.x.values, dtype=float)
        y = np.asarray(ds.y.values, dtype=float)
        if len(x) < 2 or len(y) < 2:
            raise RuntimeError("Unable to derive raster transform from STAC load.")
        xres = abs(float(x[1] - x[0]))
        yres = abs(float(y[1] - y[0]))
        return rasterio.transform.from_origin(
            float(x.min() - xres / 2),
            float(y.max() + yres / 2),
            xres,
            yres,
        )


def footprint_mask(geom_3577, shape, transform):
    return geometry_mask(
        [mapping(geom_3577)],
        out_shape=shape,
        transform=transform,
        invert=True,
        all_touched=False,
    )


@lru_cache(maxsize=1)
def load_clum_source():
    # CLUM uses the supplied world file for georeferencing
    with rasterio.Env(GDAL_GEOREF_SOURCES="WORLDFILE,PAM,INTERNAL"):
        with rasterio.open(cfg.CLUM_RASTER) as src:
            source = src.read(1)
            src_transform = src.transform
            src_crs = src.crs
            src_nodata = src.nodata

    if src_transform == Affine.identity():
        raise RuntimeError("CLUM georeferencing not loaded")

    return source, src_transform, src_crs, src_nodata


def clum_mask(shape, transform):
    destination = np.zeros(shape, dtype=np.float32)
    source, src_transform, src_crs, src_nodata = load_clum_source()
    reproject(
        source=source,
        destination=destination,
        src_transform=src_transform,
        src_crs=src_crs,
        src_nodata=src_nodata,
        dst_transform=transform,
        dst_crs=cfg.GRID_CRS,
        dst_nodata=0,
        resampling=Resampling.nearest,
    )
    return destination == float(cfg.CLUM_VALUE)


def median_ndvi(ds, geom_3577, transform):
    height = int(ds.sizes.get("y", 0))
    width = int(ds.sizes.get("x", 0))
    time_count = int(ds.sizes.get("time", 0))
    shape = (height, width)
    spatial = footprint_mask(geom_3577, shape, transform) & clum_mask(shape, transform)
    ndvi = np.full(shape, np.nan, dtype=np.float32)

    # process in chunks
    tile_size = int(cfg.PROCESSING_TILE_SIZE_PX)
    for y0 in range(0, height, tile_size):
        y1 = min(y0 + tile_size, height)
        for x0 in range(0, width, tile_size):
            x1 = min(x0 + tile_size, width)
            spatial_tile = spatial[y0:y1, x0:x1]
            if not spatial_tile.any():
                continue

            tile = ds[list(REQUIRED_ASSETS)].isel(
                y=slice(y0, y1), x=slice(x0, x1)
            ).compute(scheduler="threads", num_workers=cfg.IO_THREADS)

            red_dn = np.asarray(tile["red"].values)
            nir_dn = np.asarray(tile["nir08"].values)
            qa_pixel = np.asarray(tile["qa_pixel"].values)
            qa_radsat = np.asarray(tile["qa_radsat"].values)

            red = red_dn.astype(np.float32) * cfg.SR_SCALE + cfg.SR_OFFSET
            nir = nir_dn.astype(np.float32) * cfg.SR_SCALE + cfg.SR_OFFSET

            # missing QA is invalid
            qa_pixel_safe = np.nan_to_num(
                qa_pixel, nan=QA_BAD_BITS_0_TO_5
            ).astype(np.uint32)
            qa_radsat_safe = np.nan_to_num(qa_radsat, nan=1).astype(np.uint32)

            qa_clear = (qa_pixel_safe & QA_BAD_BITS_0_TO_5) == 0
            unsaturated = qa_radsat_safe == 0

            denominator = nir + red
            valid = (
                qa_clear
                & unsaturated
                & np.isfinite(red)
                & np.isfinite(nir)
                & np.isfinite(denominator)
                & (np.abs(denominator) > 1e-12)
                & spatial_tile[None, :, :]
            )

            ndvi_stack = np.full(red.shape, np.nan, dtype=np.float32)
            np.divide(nir - red, denominator, out=ndvi_stack, where=valid)

            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)
                tile_median = np.nanmedian(ndvi_stack, axis=0).astype(np.float32)
            tile_median[~spatial_tile] = np.nan
            ndvi[y0:y1, x0:x1] = tile_median

    ndvi[~spatial] = np.nan
    return ndvi


def circular_footprint(radius_m, exclude_center=False):
    radius_px = float(radius_m) / float(cfg.SCALE_M)
    half = int(math.ceil(radius_px))
    yy, xx = np.mgrid[-half : half + 1, -half : half + 1]
    footprint = (xx * xx + yy * yy) <= radius_px * radius_px + 1e-9
    if exclude_center:
        footprint[half, half] = False
    return footprint


def _nanmedian_window(values):
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan
    return float(np.median(values))


def _metric_suffix(value):
    text = f"{float(value):g}"
    return text.replace("-", "m").replace(".", "p")


def contrast_fraction_field(threshold):
    suffix = f"{float(threshold):.2f}".replace("-", "m").replace(".", "p")
    return f"contrast_fraction_ge_{suffix}"


def contrast_landscape_coverage_field(threshold):
    suffix = f"{float(threshold):.2f}".replace("-", "m").replace(".", "p")
    return f"contrast_landscape_coverage_ge_{suffix}"


def contrast_percentile_field(percentile):
    value = float(percentile)
    if value.is_integer():
        suffix = str(int(value))
    else:
        suffix = f"{value:g}".replace(".", "")
    return f"contrast_p{suffix}"


def local_contrast(ndvi):
    local_median = generic_filter(
        ndvi,
        function=_nanmedian_window,
        # Exclude the focal pixel so C30 compares each pixel with its local
        # background rather than including the pixel itself in that median.
        footprint=circular_footprint(cfg.BACKGROUND_RADIUS_M, exclude_center=True),
        mode="constant",
        cval=np.nan,
        output=np.float32,
    )
    contrast = (ndvi - local_median).astype(np.float32)

    valid = np.isfinite(ndvi)
    contrast[~valid] = np.nan

    # retained for the reference-threshold summaries
    reference_high = (
        valid
        & np.isfinite(contrast)
        & (contrast >= cfg.REFERENCE_CONTRAST_THRESHOLD)
    )
    return contrast, reference_high


def summarize_date_contrast(
    inputs,
    result,
):
    row = {
        "date": result.date,
        "status": result.status,
        "message": result.message,
        "landsat_observation_count": result.scene_count,
        "landsat_window_days_used": result.landsat_window_days_used,
        "closest_landsat_days": np.nan,
        "furthest_landsat_days": np.nan,
        "aoi_area_km2": np.nan,
        "pleiades_footprint_area_km2": np.nan,
        "pleiades_footprint_fraction_of_aoi": np.nan,
        "eligible_agricultural_pixels": 0,
        "valid_landsat_pixels": 0,
        "valid_coverage_fraction": np.nan,
        "usable_contrast_threshold": float(cfg.USABLE_CONTRAST_THRESHOLD),
        "usable_contrast_pixels": 0,
        "usable_contrast_fraction_valid": np.nan,
        "usable_contrast_landscape_coverage": np.nan,
        "reference_contrast_threshold": float(cfg.REFERENCE_CONTRAST_THRESHOLD),
        "reference_high_contrast_pixels": 0,
        "reference_high_contrast_fraction_valid": np.nan,
        "spatial_cells_total": 0,
        "spatial_cells_evaluable": 0,
        "spatial_evaluable_fraction": np.nan,
        "spatial_cell_p975_p10": np.nan,
        "spatial_cell_p975_p25": np.nan,
        "spatial_cell_p975_p50": np.nan,
        "spatial_cell_p975_p75": np.nan,
        "spatial_cell_p975_p90": np.nan,
        "spatial_cell_p975_iqr": np.nan,
    }
    for percentile in cfg.CONTRAST_PERCENTILES:
        row[contrast_percentile_field(percentile)] = np.nan
    for threshold in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS:
        fraction_field = contrast_fraction_field(threshold)
        landscape_field = contrast_landscape_coverage_field(threshold)
        row[fraction_field] = np.nan
        row[landscape_field] = np.nan
        row[f"spatial_cell_{fraction_field}_p25"] = np.nan
        row[f"spatial_cell_{fraction_field}_p50"] = np.nan
        row[f"spatial_cell_{landscape_field}_p25"] = np.nan
        row[f"spatial_cell_{landscape_field}_p50"] = np.nan

    # footprint area is reported separately from the contrast score
    geom = geometry_for_date(inputs, result.date)
    aoi_area_km2 = float(inputs.aoi.area / 1e6)
    footprint_area_km2 = float(geom.area / 1e6)
    row["aoi_area_km2"] = aoi_area_km2
    row["pleiades_footprint_area_km2"] = footprint_area_km2
    row["pleiades_footprint_fraction_of_aoi"] = (
        float(footprint_area_km2 / aoi_area_km2) if aoi_area_km2 > 0 else np.nan
    )

    offsets = []
    center = date.fromisoformat(result.date)
    for item in result.scene_items:
        if item.datetime is not None:
            offsets.append(abs((item.datetime.date() - center).days))
    if offsets:
        row["closest_landsat_days"] = int(min(offsets))
        row["furthest_landsat_days"] = int(max(offsets))

    if (
        result.status != "OK"
        or result.ndvi is None
        or result.contrast is None
        or result.high is None
        or result.transform is None
    ):
        return row

    shape = result.ndvi.shape
    eligible = footprint_mask(geom, shape, result.transform) & clum_mask(shape, result.transform)
    valid = eligible & np.isfinite(result.ndvi)
    reference_high = (
        valid
        & np.isfinite(result.contrast)
        & (result.contrast >= cfg.REFERENCE_CONTRAST_THRESHOLD)
    )

    eligible_n = int(eligible.sum())
    valid_n = int(valid.sum())
    reference_high_n = int(reference_high.sum())

    row.update(
        {
            "eligible_agricultural_pixels": eligible_n,
            "valid_landsat_pixels": valid_n,
            "valid_coverage_fraction": (
                float(valid_n / eligible_n) if eligible_n > 0 else np.nan
            ),
            "reference_high_contrast_pixels": reference_high_n,
            "reference_high_contrast_fraction_valid": (
                float(reference_high_n / valid_n) if valid_n > 0 else np.nan
            ),
        }
    )

    values = result.contrast[valid & np.isfinite(result.contrast)]
    if values.size:
        for percentile in cfg.CONTRAST_PERCENTILES:
            row[contrast_percentile_field(percentile)] = float(
                np.percentile(values, percentile)
            )
        for threshold in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS:
            threshold = float(threshold)
            count = int(np.count_nonzero(values >= threshold))
            row[contrast_fraction_field(threshold)] = float(count / values.size)
            row[contrast_landscape_coverage_field(threshold)] = (
                float(count / eligible_n) if eligible_n > 0 else np.nan
            )

        usable_count = int(np.count_nonzero(values >= float(cfg.USABLE_CONTRAST_THRESHOLD)))
        row["usable_contrast_pixels"] = usable_count
        row["usable_contrast_fraction_valid"] = float(usable_count / values.size)
        row["usable_contrast_landscape_coverage"] = (
            float(usable_count / eligible_n) if eligible_n > 0 else np.nan
        )

    # aligned 1-km summaries
    evaluable_cells, all_cells = summarize_cells(
        result.date,
        geom,
        result.ndvi,
        result.contrast,
        reference_high,
        result.transform,
        result.scene_count,
    )
    result.selected = evaluable_cells  # retained for backward-compatible DateResult storage
    result.all_cells = all_cells

    if not all_cells.empty:
        row["spatial_cells_total"] = int(len(all_cells))
        evaluable = all_cells["spatial_evaluable"].fillna(False).astype(bool)
        n_eval = int(evaluable.sum())
        row["spatial_cells_evaluable"] = n_eval
        row["spatial_evaluable_fraction"] = float(n_eval / len(all_cells))

        if n_eval:
            p975_values = pd.to_numeric(
                all_cells.loc[evaluable, "contrast_p975"], errors="coerce"
            ).dropna().to_numpy(dtype=float)
            if p975_values.size:
                q10, q25, q50, q75, q90 = np.percentile(
                    p975_values, [10, 25, 50, 75, 90]
                ).astype(float)
                row["spatial_cell_p975_p10"] = float(q10)
                row["spatial_cell_p975_p25"] = float(q25)
                row["spatial_cell_p975_p50"] = float(q50)
                row["spatial_cell_p975_p75"] = float(q75)
                row["spatial_cell_p975_p90"] = float(q90)
                row["spatial_cell_p975_iqr"] = float(q75 - q25)

            for threshold in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS:
                for field in (
                    contrast_fraction_field(threshold),
                    contrast_landscape_coverage_field(threshold),
                ):
                    cell_values = pd.to_numeric(
                        all_cells.loc[evaluable, field], errors="coerce"
                    ).dropna().to_numpy(dtype=float)
                    if cell_values.size:
                        q25, q50 = np.percentile(cell_values, [25, 50]).astype(float)
                        row[f"spatial_cell_{field}_p25"] = float(q25)
                        row[f"spatial_cell_{field}_p50"] = float(q50)

    return row


def aligned_grid_cells(geom_3577):
    size = float(cfg.GRID_SIZE_M)
    minx, miny, maxx, maxy = geom_3577.bounds
    x0 = math.floor(minx / size) * size
    x1 = math.ceil(maxx / size) * size
    y0 = math.floor(miny / size) * size
    y1 = math.ceil(maxy / size) * size

    cells = []
    cell_id = 1
    y = y0
    while y < y1:
        x = x0
        while x < x1:
            clipped = make_valid(box(x, y, x + size, y + size).intersection(geom_3577))
            if not clipped.is_empty and clipped.area > 0:
                cells.append((cell_id, clipped, float(clipped.area / 1e6)))
                cell_id += 1
            x += size
        y += size
    return cells


def summarize_cells(
    date_string,
    geom_3577,
    ndvi,
    contrast,
    reference_high,
    transform,
    scene_count,
):
    cells = aligned_grid_cells(geom_3577)
    metric_columns = [
        contrast_percentile_field(p) for p in cfg.CONTRAST_PERCENTILES
    ] + [
        contrast_fraction_field(t) for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
    ] + [
        contrast_landscape_coverage_field(t) for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
    ]
    columns = [
        "date",
        *metric_columns,
        "reference_high_contrast_pixels",
        "reference_high_contrast_fraction_valid",
        "eligible_agricultural_pixels",
        "valid_landsat_pixels",
        "valid_coverage_fraction",
        "usable_contrast_threshold",
        "usable_contrast_pixels",
        "usable_contrast_fraction_valid",
        "usable_contrast_landscape_coverage",
        "agricultural_fraction",
        "valid_area_km2",
        "cell_area_km2",
        "cell_area_fraction_of_1km",
        "spatial_evaluable",
        "landsat_scene_count",
        "geometry",
    ]
    if not cells:
        empty = gpd.GeoDataFrame(columns=columns, geometry="geometry", crs=cfg.GRID_CRS)
        return empty.copy(), empty.copy()

    cell_id_raster = rasterize(
        [(mapping(geom), cell_id) for cell_id, geom, _ in cells],
        out_shape=ndvi.shape,
        transform=transform,
        fill=0,
        dtype="int32",
        all_touched=False,
    )

    records = []
    height, width = ndvi.shape
    eligible = footprint_mask(geom_3577, ndvi.shape, transform) & clum_mask(ndvi.shape, transform)
    inv = ~transform

    for cell_id, cell_geom, cell_area_km2 in cells:
        minx, miny, maxx, maxy = cell_geom.bounds
        c0f, r1f = inv * (minx, miny)
        c1f, r0f = inv * (maxx, maxy)
        row0 = max(0, int(math.floor(min(r0f, r1f))) - 1)
        row1 = min(height, int(math.ceil(max(r0f, r1f))) + 1)
        col0 = max(0, int(math.floor(min(c0f, c1f))) - 1)
        col1 = min(width, int(math.ceil(max(c0f, c1f))) + 1)

        ids = cell_id_raster[row0:row1, col0:col1]
        in_cell = ids == cell_id
        ndvi_view = ndvi[row0:row1, col0:col1]
        eligible_view = eligible[row0:row1, col0:col1]
        contrast_view = contrast[row0:row1, col0:col1]
        reference_high_view = reference_high[row0:row1, col0:col1]

        eligible_mask = in_cell & eligible_view
        eligible_count = int(eligible_mask.sum())
        cell_pixel_count = int(in_cell.sum())
        agricultural_fraction = (
            float(eligible_count / cell_pixel_count) if cell_pixel_count > 0 else np.nan
        )
        valid_mask = eligible_mask & np.isfinite(ndvi_view)
        valid_count = int(valid_mask.sum())
        valid_coverage = (
            float(valid_count / eligible_count) if eligible_count > 0 else np.nan
        )
        reference_high_count = int((in_cell & reference_high_view).sum())

        contrast_values = contrast_view[
            valid_mask & np.isfinite(contrast_view)
        ]
        metrics = {}
        for percentile in cfg.CONTRAST_PERCENTILES:
            metrics[contrast_percentile_field(percentile)] = (
                float(np.percentile(contrast_values, percentile))
                if contrast_values.size else np.nan
            )
        for threshold in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS:
            threshold = float(threshold)
            count = int(np.count_nonzero(contrast_values >= threshold))
            metrics[contrast_fraction_field(threshold)] = (
                float(count / contrast_values.size) if contrast_values.size else np.nan
            )
            metrics[contrast_landscape_coverage_field(threshold)] = (
                float(count / eligible_count) if eligible_count > 0 else np.nan
            )

        usable_count = int(
            np.count_nonzero(contrast_values >= float(cfg.USABLE_CONTRAST_THRESHOLD))
        )
        usable_fraction_valid = (
            float(usable_count / contrast_values.size) if contrast_values.size else np.nan
        )
        usable_landscape_coverage = (
            float(usable_count / eligible_count) if eligible_count > 0 else np.nan
        )

        reference_high_fraction_valid = (
            float(reference_high_count / valid_count) if valid_count > 0 else np.nan
        )
        cell_area_fraction = float(cell_area_km2 / 1.0)
        # minimum pixels for a usable cell summary
        spatial_evaluable = bool(
            cell_area_fraction >= cfg.MIN_SPATIAL_CELL_AREA_FRACTION
            and eligible_count > 0
            and valid_count >= cfg.MIN_SPATIAL_CELL_VALID_PIXELS
        )

        records.append(
            {
                "date": date_string,
                **metrics,
                "reference_high_contrast_pixels": reference_high_count,
                "reference_high_contrast_fraction_valid": reference_high_fraction_valid,
                "eligible_agricultural_pixels": eligible_count,
                "valid_landsat_pixels": valid_count,
                "valid_coverage_fraction": valid_coverage,
                "usable_contrast_threshold": float(cfg.USABLE_CONTRAST_THRESHOLD),
                "usable_contrast_pixels": usable_count,
                "usable_contrast_fraction_valid": usable_fraction_valid,
                "usable_contrast_landscape_coverage": usable_landscape_coverage,
                "agricultural_fraction": agricultural_fraction,
                "valid_area_km2": valid_count * cfg.SCALE_M * cfg.SCALE_M / 1e6,
                "cell_area_km2": cell_area_km2,
                "cell_area_fraction_of_1km": cell_area_fraction,
                "spatial_evaluable": spatial_evaluable,
                "landsat_scene_count": scene_count,
                "geometry": cell_geom,
            }
        )

    all_cells = gpd.GeoDataFrame(records, geometry="geometry", crs=cfg.GRID_CRS)
    all_cells = all_cells[all_cells["eligible_agricultural_pixels"] > 0].copy()
    evaluable_cells = all_cells[all_cells["spatial_evaluable"]].copy()
    if "usable_contrast_landscape_coverage" in evaluable_cells:
        evaluable_cells = evaluable_cells.sort_values(
            ["usable_contrast_landscape_coverage", "valid_coverage_fraction", "contrast_p975"],
            ascending=[False, False, False],
            na_position="last",
        ).reset_index(drop=True)
    return evaluable_cells, all_cells


def empty_result(
    date_string,
    status,
    message,
    items=None,
    landsat_window_days_used=None,
):
    metric_columns = [
        contrast_percentile_field(p) for p in cfg.CONTRAST_PERCENTILES
    ] + [
        contrast_fraction_field(t) for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
    ] + [
        contrast_landscape_coverage_field(t) for t in cfg.CONTRAST_DIAGNOSTIC_THRESHOLDS
    ]
    columns = [
        "date",
        *metric_columns,
        "reference_high_contrast_pixels",
        "reference_high_contrast_fraction_valid",
        "eligible_agricultural_pixels",
        "valid_landsat_pixels",
        "valid_coverage_fraction",
        "usable_contrast_threshold",
        "usable_contrast_pixels",
        "usable_contrast_fraction_valid",
        "usable_contrast_landscape_coverage",
        "agricultural_fraction",
        "valid_area_km2",
        "cell_area_km2",
        "cell_area_fraction_of_1km",
        "spatial_evaluable",
        "landsat_scene_count",
        "geometry",
    ]
    empty = gpd.GeoDataFrame(columns=columns, geometry="geometry", crs=cfg.GRID_CRS)
    return DateResult(
        date=date_string,
        status=status,
        message=message,
        scene_items=list(items or []),
        selected=empty.copy(),
        all_cells=empty.copy(),
        landsat_window_days_used=landsat_window_days_used,
    )


def compute_date(
    catalog,
    inputs,
    date_string,
    keep_arrays=False,
):
    geom = geometry_for_date(inputs, date_string)
    window_used = int(cfg.LANDSAT_WINDOW_DAYS)
    items = search_landsat(catalog, date_string, geom, window_days=window_used)
    if not items:
        return empty_result(
            date_string,
            "NO_SCENES",
            f"No Landsat 8 Tier-1 observations found within +/-{window_used} days.",
            landsat_window_days_used=window_used,
        )

    last_error = None
    for attempt in range(cfg.ASSET_READ_RETRIES + 1):
        try:
            ds = load_landsat_stack(items, geom)
            transform = grid_transform(ds)
            ndvi = median_ndvi(ds, geom, transform)
            break
        except MemoryError:
            raise
        except Exception as exc:
            last_error = exc
            if attempt >= cfg.ASSET_READ_RETRIES:
                raise
            warnings.warn(
                f"Landsat asset read/compute failed for {date_string}; retry "
                f"{attempt + 1}/{cfg.ASSET_READ_RETRIES} after refreshing signed URLs: {exc}"
            )
            time.sleep(cfg.ASSET_READ_RETRY_SECONDS)
            items = search_landsat(catalog, date_string, geom, window_days=window_used)
            if not items:
                raise RuntimeError("No Landsat scenes after retry") from last_error

    if not np.isfinite(ndvi).any():
        return empty_result(
            date_string,
            "NO_VALID_PIXELS",
            "Observations were found, but no pixels survived QA + CLUM + footprint masking.",
            items,
            landsat_window_days_used=window_used,
        )

    contrast, high = local_contrast(ndvi)
    empty = gpd.GeoDataFrame(geometry=[], crs=cfg.GRID_CRS)

    result = DateResult(
        date=date_string,
        status="OK",
        message="",
        scene_items=items,
        selected=empty.copy(),
        all_cells=empty.copy(),
        transform=transform,
        landsat_window_days_used=window_used,
    )
    if keep_arrays:
        result.ndvi = ndvi
        result.contrast = contrast
        result.high = high
    return result


def write_geojson(gdf, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if gdf.empty:
        path.write_text(json.dumps({"type": "FeatureCollection", "features": []}), encoding="utf-8")
        return
    out = gdf.to_crs("EPSG:4326")
    out.to_file(path, driver="GeoJSON")


def write_scene_list(date_string, items):
    out_dir = cfg.LOG_DIR / "scene_lists"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"landsat_scenes_{date_string.replace('-', '')}.csv"
    scene_inventory(items, reference_date=date_string).to_csv(path, index=False)
    return path

