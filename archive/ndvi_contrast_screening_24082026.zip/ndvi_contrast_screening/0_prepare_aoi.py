#!/usr/bin/env python3
# prepare merged AOI

import argparse
import tempfile
import zipfile
from pathlib import Path

import geopandas as gpd
import pandas as pd
from shapely import make_valid

DEFAULT_INPUT = Path("AOI.zip")
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "inputs" / "AOI_merged.gpkg"
DEFAULT_CRS = "EPSG:3577"


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=DEFAULT_INPUT, help="ZIP containing AOI shapefiles")
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Output GeoPackage")
    p.add_argument("--crs", default=DEFAULT_CRS, help="Output projected CRS")
    return p.parse_args()


def main():
    args = parse_args()
    if not args.input.exists():
        raise FileNotFoundError(f"AOI ZIP not found: {args.input.resolve()}")

    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "src"
        src.mkdir()
        with zipfile.ZipFile(args.input) as z:
            z.extractall(src)

        frames = []
        for shp in sorted(src.rglob("*.shp")):
            gdf = gpd.read_file(shp)
            if gdf.empty:
                continue
            if gdf.crs is None:
                raise RuntimeError(f"Missing CRS: {shp}")
            gdf = gdf.to_crs(args.crs)
            gdf = gdf[gdf.geometry.notna()].copy()
            gdf["geometry"] = gdf.geometry.map(make_valid)
            frames.append(gdf[["geometry"]])

        if not frames:
            raise RuntimeError("No non-empty AOI shapefiles were found in the ZIP.")

        merged = gpd.GeoDataFrame(
            pd.concat(frames, ignore_index=True),
            geometry="geometry",
            crs=args.crs,
        )
        dissolved = make_valid(merged.geometry.union_all())
        out = gpd.GeoDataFrame([{"name": "AOI", "geometry": dissolved}], crs=args.crs)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        args.output.unlink()
    out.to_file(args.output, layer="aoi", driver="GPKG")

    print(f"Input files: {len(frames):,}")
    print(f"Output CRS: {args.crs}")
    print(f"Wrote: {args.output.resolve()}")


if __name__ == "__main__":
    main()
